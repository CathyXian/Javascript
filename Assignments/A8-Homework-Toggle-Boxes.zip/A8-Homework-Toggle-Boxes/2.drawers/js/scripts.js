var drawers= document.querySelectorAll('.drawer');



/*-------------------------------------
| for each function
-------------------------------------*/

drawers.forEach(function(theMove){
        theMove.addEventListener("click", function(){
         
     }
   });
});
